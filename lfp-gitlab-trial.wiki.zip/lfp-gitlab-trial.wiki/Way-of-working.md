# Eventi

## [Sprint Planning](Way-of-working/Sprint-Planning)

## [Daily Standup](Way-of-working/Daily-Standup)

## [Sprint Review](Way-of-working/Sprint-Review)

## [Sprint Retrospectives](Way-of-working/Sprint-Retrospective)

# [Definition of Done (DoD)](Way-of-working/DoD)

* [Software Items](DoD---Software-Items)
  * Unit tested
  * Committed to GitLab
  * Deployed to Ocean
  * If needed, usage instructions written (or updated)
* Public Presentations
  * Format: PPTX
  * Template: <TBD>
# [Definition of Ready (DoR)](Way-of-working/DoR)

## [Glossario(Way-of-working/Glossario)]
