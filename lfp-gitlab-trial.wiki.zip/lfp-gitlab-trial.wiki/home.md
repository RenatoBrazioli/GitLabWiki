# [Way of Working](Way-of-working)
_Way of Working_ (**WoW**) si riferisce all'insieme di regole, convenzioni, documenti che facilitano la collaborazione all'interno di un team.

Di fatto, descrive la MVB, Minimal Viable Bureacracy, che un team decide di adottare. È frutto di un lavoro collaborativo e soggetta a cambiamenti, per aumentare efficacia ed efficenza del team.